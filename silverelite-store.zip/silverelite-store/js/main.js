// main.js
async function fetchProducts(){
  const r = await fetch('data/products.json');
  return await r.json();
}

function createProductCard(p){
  return `
  <div class="card">
    <a href="product.html?slug=${p.slug}">
      <img src="images/${p.images[0]}" alt="${p.title}">
    </a>
    <h4>${p.title}</h4>
    <p>${p.short}</p>
    <div class="price">₹${p.price_inr}</div>
    <button onclick="addToCart('${p.id}')">Add to Cart</button>
  </div>`;
}

async function loadFeatured(){
  const products = await fetchProducts();
  const featured = products.slice(0,4);
  document.getElementById('products').innerHTML = featured.map(createProductCard).join('');
}

async function loadAllProducts(){
  const products = await fetchProducts();
  document.getElementById('product-grid').innerHTML = products.map(createProductCard).join('');
}

function getQueryParam(name) {
  const url = new URL(location.href);
  return url.searchParams.get(name);
}

async function renderProductFromSlug(){
  const slug = getQueryParam('slug');
  const products = await fetchProducts();
  const p = products.find(x => x.slug === slug);
  if (!p) { document.getElementById('product-area').innerText = 'Product not found'; return; }
  document.title = p.title + ' — SilverÉlite';
  const html = `
    <div class="product">
      <img src="images/${p.images[0]}" alt="${p.title}" class="product-image">
      <div class="product-info">
        <h2>${p.title}</h2>
        <p class="price">₹${p.price_inr}</p>
        <p>${p.long}</p>
        <p><strong>Purity:</strong> ${p.purity}</p>
        <p><strong>Stock:</strong> ${p.stock}</p>
        <button onclick="addToCart('${p.id}')">Add to Cart</button>
      </div>
    </div>`;
  document.getElementById('product-area').innerHTML = html;
}

// CART functions: shared
function getCart(){
  return JSON.parse(localStorage.getItem('se_cart')||'[]');
}
function addToCart(productId){
  const cart = getCart();
  const existing = cart.find(i=>i.id===productId);
  if (existing) existing.qty += 1; else cart.push({id: productId, qty:1});
  localStorage.setItem('se_cart', JSON.stringify(cart));
  updateCartCount();
  alert('Added to cart');
}
function updateCartCount(){
  const count = getCart().reduce((s,i)=>s+i.qty,0);
  const el = document.getElementById('cart-count');
  if (el) el.textContent = count;
}
