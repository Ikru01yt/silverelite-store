// cart.js
(async function(){
  const cartEl = document.getElementById('cart-items');
  const summaryEl = document.getElementById('cart-summary');
  const products = await (await fetch('data/products.json')).json();
  const cart = JSON.parse(localStorage.getItem('se_cart')||'[]');

  if (!cartEl) return;

  if (cart.length===0){
    cartEl.innerHTML = '<p>Your cart is empty.</p>';
    summaryEl.innerHTML = '';
    window.dispatchEvent(new Event('paypalReady'));
    return;
  }

  let html = '<ul>';
  let totalINR = 0, totalUSD = 0;
  cart.forEach(item=>{
    const p = products.find(x=>x.id===item.id);
    if (!p) return;
    const subtotal = p.price_inr * item.qty;
    totalINR += subtotal;
    totalUSD += (p.price_usd || (p.price_inr/80)) * item.qty;
    html += `<li>
      <img src="images/${p.images[0]}" style="width:60px">
      <strong>${p.title}</strong> x ${item.qty} — ₹${subtotal}
    </li>`;
  });
  html += '</ul>';
  cartEl.innerHTML = html;
  summaryEl.innerHTML = `<p><strong>Total:</strong> ₹${totalINR} (${totalUSD.toFixed(2)} USD)</p>`;

  // Make total available for PayPal script
  window.paypalTotalUSD = totalUSD.toFixed(2);
  // signal PayPal render function
  window.dispatchEvent(new Event('paypalReady'));
})();
